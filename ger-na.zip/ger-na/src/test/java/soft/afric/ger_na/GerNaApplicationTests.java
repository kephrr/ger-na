package soft.afric.ger_na;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerNaApplicationTests {

	@Test
	void contextLoads() {
	}

}
