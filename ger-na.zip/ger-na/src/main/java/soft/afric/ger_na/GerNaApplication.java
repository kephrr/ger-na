package soft.afric.ger_na;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerNaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GerNaApplication.class, args);
	}

}
